package org.katlas.JavaKh.algebra;

import java.util.List;

public interface DirectSum<T> extends List<T> {

}
