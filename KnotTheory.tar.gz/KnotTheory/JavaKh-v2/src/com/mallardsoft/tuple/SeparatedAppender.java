package com.mallardsoft.tuple;

public interface SeparatedAppender {

	public void appendString(StringBuffer buffer, String separator);
	
}
