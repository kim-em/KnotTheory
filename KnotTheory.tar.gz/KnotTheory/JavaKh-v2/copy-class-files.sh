cp -R output/* bin
