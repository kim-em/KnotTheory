nohup nice -n 19 ./upload_script.sh $1 $2 $3 $4 &
